-- everything space
require("__planet-signus__.prototypes.planet.signus_star_system")
require("__planet-signus__.prototypes.planet.signus_ring.signus_planet")
require("__planet-signus__.prototypes.planet.signus_space_routes")